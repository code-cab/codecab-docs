let stage = new CStage({width: 400, height: 200});

let blocks = new CSprite("scratch-multi.png");
CStage.childById("scratchmulti").scale = 0.547;

CSprite.prototype.aniMove = async function(dx, dy) {
	await this.glideTo(this.x + dx, this.y + dy, 0.1);
	await this.delay(0.05);
}

let a1 = new CSprite("arrow right.png");
let a2 = new CSprite("arrow right.png");

a1.scale = 0.05;
a2.scale = 0.05;
a1.goto(-150, -44);
a2.goto(20, -44);



a1.onStart(async function() {
	await this.delay(1);
	await this.aniMove(0, 25);
	await this.aniMove(0, 20);
	while (true) {
		let loopy = this.y;
		await this.aniMove(0, 18);
		await this.delay(0.5);
		await this.aniMove(0, 18);
		await this.aniMove(0, 18);
		await this.delay(0.5);
		await this.aniMove(0, loopy - this.y);
	}
});

a2.onStart(async function() {
	await this.delay(1);
	await this.aniMove(0, 25);
	await this.aniMove(0, 20);
	while (true) {
		let loopy = this.y;
		await this.delay(0.3);
		await this.aniMove(0, 18);
		await this.delay(0.3);
		await this.aniMove(0, loopy - this.y);
	}
});


